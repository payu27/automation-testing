package com.ng1;

import org.testng.annotations.Test;

public class Test1 {
  @Test
  public void test1()
  {
	  System.err.println("This is test1 method..");
  }

}
