package com.ng1;

import org.testng.annotations.Test;

public class SecondDemo 
{
	@Test(priority = 0)
	public void test()
	{
		System.out.println("This is main test..");
	}
	
	@Test(priority = 3)
	public void rest()
	{
		System.out.println("This is main rest..");
	}
	
	@Test(priority = 1)
	public void best()
	{
		System.out.println("This is main best..");
	}
	
	@Test(priority = 2)
	public void zest()
	{
		System.out.println("This is main zest..");
	}
}
