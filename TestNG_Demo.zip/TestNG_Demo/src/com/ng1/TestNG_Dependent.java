package com.ng1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class TestNG_Dependent
{
	WebDriver driver = null;
	//@Ignore
	@Test
	public void beforeSetUp() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "D:\\seleniium\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.get("https://www.saucedemo.com/");
		Thread.sleep(2000);
	}
	
	@Test(dependsOnMethods = {"beforeSetUp"})
	public void enterUserName() throws InterruptedException
	{
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		Thread.sleep(2000);
	}
	
	@Test(dependsOnMethods = {"enterUserName"})
	public void enterPassword() throws InterruptedException
	{
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		Thread.sleep(2000);
	}
	
	@Test(dependsOnMethods = {"enterPassword"})
	public void enterLogin() throws InterruptedException
	{
		driver.findElement(By.id("login-button")).click();;
		Thread.sleep(2000);
	}
	
	@Test(dependsOnMethods = {"enterLogin"})
	public void sideMenu() throws InterruptedException
	{
		driver.findElement(By.id("react-burger-menu-btn")).click();
		Thread.sleep(2000);
	}
	
	@Test(dependsOnMethods = {"sideMenu"})
	public void logOut() throws InterruptedException
	{
		driver.findElement(By.id("logout_sidebar_link")).click();
		Thread.sleep(2000);
	}
	
	@Test(dependsOnMethods = {"logOut"})
	public void afterTest()
	{
		System.out.println("Bye Bye..");
		driver.close();
	}
}
