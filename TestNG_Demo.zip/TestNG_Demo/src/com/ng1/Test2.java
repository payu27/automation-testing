package com.ng1;

import org.testng.annotations.Test;

public class Test2
{
	  @Test
	  public void test2()
	  {
		  System.err.println("This is test2 method..");
	  }
}
